<DIV class="product-item float-clear" style="clear:both;margin-top:2%">

	<DIV class="col-sm-2" style="margin-top:1%" ><input type="checkbox" name="item_index[]"/></DIV>


<DIV class="col-sm-6" style="margin-top:1%"><input type="date" name="alldate[]" class="form-control"/></DIV>

</DIV>